package my.edu.utar.individualassignment;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.view.View;

public class highlight_view extends View {
    public boolean isHighlighted;

    public highlight_view(Context context) {
        super(context);
        isHighlighted = false;
    }

    public void highlight() {
        isHighlighted = true;
        invalidate();
    }

    public void unhighlight() {
        isHighlighted = false;
        invalidate();
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int radius = Math.min(width, height) / 2;

        // Draw the highlighted area
        if (isHighlighted) {
            //canvas.drawColor(Color.WHITE);
            canvas.clipRect(0, 0, width, height);

            Paint paint = new Paint();
            paint.setColor(Color.CYAN);
            canvas.drawCircle(width / 2f, height / 2f, radius, paint);
        } else {
            canvas.drawColor(Color.TRANSPARENT);
        }
    }

}
