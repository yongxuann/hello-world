package my.edu.utar.individualassignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class score_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        Button QuitButton = findViewById(R.id.quitButton);
        QuitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(score_activity.this, Home.class);
                startActivity(intent);
            }
        });

        // Get the high scores from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("highestScores", MODE_PRIVATE);
        Map<String, ?> scoresMap = sharedPreferences.getAll();

        // Convert the scores map to a list of Score objects
        List<Score> scoresList = new ArrayList<>();
        for (Map.Entry<String, ?> entry : scoresMap.entrySet()) {
            String name = entry.getKey();
            int score = Integer.parseInt(entry.getValue().toString());
            Score s = new Score(name, score);
            scoresList.add(s);
        }

        // Sort the scores list in descending order by score
        Collections.sort(scoresList);

        // Display the top 25 scores in a ListView
        ListView listView = findViewById(R.id.high_scores_list);
        ArrayAdapter<Score> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, scoresList.subList(0, Math.min(scoresList.size(), 25)));
        listView.setAdapter(adapter);
    }
}
